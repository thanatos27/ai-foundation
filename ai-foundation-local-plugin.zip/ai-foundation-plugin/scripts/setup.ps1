param([Parameter(Mandatory=$true)][string]$RepositoryPath)
$ErrorActionPreference = 'Stop'
$repo = [System.IO.Path]::GetFullPath($RepositoryPath)
if (-not (Test-Path -LiteralPath (Join-Path $repo 'package.json') -PathType Leaf)) { throw 'package.json is missing at repository path.' }
if (-not (Test-Path -LiteralPath (Join-Path $repo 'dist/index.js') -PathType Leaf)) { throw 'dist/index.js is missing. Build AI Foundation first.' }
$pluginRoot = Split-Path -Parent $PSScriptRoot
[System.IO.File]::WriteAllText((Join-Path $pluginRoot 'ai-foundation-path.txt'), $repo, (New-Object System.Text.UTF8Encoding($false)))
Write-Host "Configured AI Foundation path: $repo"
Write-Host "Check connection by running: powershell.exe -NoProfile -File `"$PSScriptRoot/start.ps1`""
