---
name: ai-foundation
description: "Use when managing the user's personal tasks, schedules, Notion collections, Obsidian knowledge, or GitHub project metadata through the locally connected AI Foundation MCP server."
---

Use the existing `ai-foundation` MCP tools as the source for supported actions. Do not claim an action succeeded without a successful tool result. For destructive or broad edits, verify the target and seek explicit confirmation. The external providers remain sources of truth. Avoid exposing local paths, OAuth tokens, or credentials in replies.
