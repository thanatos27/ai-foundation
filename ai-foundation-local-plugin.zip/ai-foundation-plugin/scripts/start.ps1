$ErrorActionPreference = 'Stop'
try {
    $pluginRoot = Split-Path -Parent $PSScriptRoot
    $pathFile = Join-Path $pluginRoot 'ai-foundation-path.txt'
    $repoRoot = $env:AI_FOUNDATION_ROOT
    if ([string]::IsNullOrWhiteSpace($repoRoot)) {
        if (-not (Test-Path -LiteralPath $pathFile -PathType Leaf)) {
            throw "AI Foundation path is missing. Run scripts/setup.ps1 to create ai-foundation-path.txt."
        }
        $repoRoot = (Get-Content -LiteralPath $pathFile -Raw -Encoding UTF8).Trim()
    }
    $repoRoot = [System.IO.Path]::GetFullPath($repoRoot)
    $entrypoint = Join-Path $repoRoot 'dist/index.js'
    $config = Join-Path $repoRoot 'config.local.yaml'
    if (-not (Test-Path -LiteralPath $entrypoint -PathType Leaf)) {
        throw "MCP entrypoint not found: $entrypoint. Run npm install and npm run build in the AI Foundation repository."
    }
    if (-not (Test-Path -LiteralPath $config -PathType Leaf)) {
        throw "Local config not found: $config. Create config.local.yaml without committing secrets."
    }
    $node = (Get-Command node.exe -ErrorAction Stop).Source
    Set-Location -LiteralPath $repoRoot
    & $node $entrypoint '--config' $config
    exit $LASTEXITCODE
} catch {
    [Console]::Error.WriteLine('[ai-foundation-plugin] ' + $_.Exception.Message)
    exit 1
}
