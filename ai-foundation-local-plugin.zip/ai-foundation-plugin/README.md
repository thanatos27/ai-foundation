# AI Foundation Local Plugin

Personal Windows plugin that launches the existing AI Foundation server unchanged over stdio.

## Prerequisites

- Windows PowerShell 5.1 or newer; Node.js >=24; npm >=11
- Existing AI Foundation repository cloned locally, `npm install` and `npm run build` completed
- `config.local.yaml` and `.env` configured **inside the existing repository** (never put credentials in this plugin)

## Setup

In PowerShell, replace paths with the actual ones:

```powershell
cd 'C:\path\to\ai-foundation'
npm install
npm run build

cd 'C:\path\to\ai-foundation-plugin'
.\scripts\setup.ps1 -RepositoryPath 'C:\path\to\ai-foundation'
```

If PowerShell execution policy blocks setup, use:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File '.\scripts\setup.ps1' -RepositoryPath 'C:\path\to\ai-foundation'
```

The setup writes only the local **repository directory** to `ai-foundation-path.txt`. No credentials are copied. Alternatively set `AI_FOUNDATION_ROOT` in the environment visible to ChatGPT Desktop.

## Register

Install/add the **unpacked `ai-foundation-plugin` directory** via ChatGPT Desktop's local plugin installation workflow if that build exposes local plugin support. The package declares a single stdio MCP server in `mcp.json`. Restart/reload the app after installation and enable the plugin. Local plugin support varies by Desktop build; do not assume account-only or cloud connector installation can launch local processes.

## Test

First ensure `node --version` shows 24+, and `Test-Path 'C:\path\to\ai-foundation\dist\index.js'` is True.

Use a local MCP Inspector or Desktop's tool discovery to verify `tools/list`. Because stdio output is JSON-RPC, **do not type plain commands into the running server**. Check a read-only call (`task_list` or `project_list`) first. The PowerShell launcher writes errors to stderr. If it exits due to config or token errors, check the existing repository's `config.local.yaml` and `.env`.

## Future HTTP deployment

Replace only the MCP transport in `mcp.json` with a verified remote `streamable-http` endpoint once a cloud server exists, and configure authentication. Never expose a personal stdio process or local credentials directly on the public Internet.
